
export interface Chapter {
  id: string;
  title: string;
  content: string;
  order: number;
}

export type AtmosphereType = 'none' | 'rain' | 'cafe' | 'fireplace' | 'forest';

export interface BookSettings {
  fontFamily: string;
  fontSize: string;
  lineHeight: string;
  pageColor: string; // hex code or tailwind class
  textColor: string;
  pageSize: 'a4' | 'a5' | 'letter';
  margins: 'compact' | 'normal' | 'wide';
  textAlign?: 'left' | 'justify' | 'center';
  atmosphere?: AtmosphereType;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  description: string;
  researchNotes?: string; // New: Scratchpad for authors
  tags?: string[]; // New: Discovery tags
  coverUrl?: string;
  chapters: Chapter[];
  status: 'draft' | 'published';
  price?: number;
  category: string;
  settings?: BookSettings;
}

export enum AppView {
  LIBRARY = 'library',
  WRITER = 'writer',
  DESIGN = 'design',
  STORE = 'store',
  DASHBOARD = 'dashboard'
}

export interface User {
  name: string;
  email: string;
  avatar?: string;
}

export type ToastType = 'success' | 'error' | 'info';

export interface ToastMessage {
  id: string;
  message: string;
  type: ToastType;
}


import React, { useState } from 'react';
import { Book, ToastType } from '../types';
import { generateCoverImage } from '../services/geminiService';

interface DesignCenterProps {
  book: Book;
  onUpdateBook: (book: Book) => void;
  addToast: (message: string, type: ToastType) => void;
}

const STYLE_PRESETS = [
  { id: 'cinematic', label: 'Cinematográfico', prompt: 'Estilo cinematográfico épico, iluminação dramática, alta resolução, 8k, detalhado.' },
  { id: 'minimalist', label: 'Minimalista', prompt: 'Design minimalista, vetorial, cores sólidas, limpo, simbólico, arte abstrata.' },
  { id: 'fantasy', label: 'Fantasia', prompt: 'Arte de fantasia digital, mágico, etéreo, pintura a óleo detalhada, estilo D&D.' },
  { id: 'watercolor', label: 'Aquarela', prompt: 'Pintura em aquarela suave, cores pastéis, artístico, papel texturizado, delicado.' },
  { id: 'cyberpunk', label: 'Cyberpunk', prompt: 'Futurista, luzes neon, cidade distópica, alta tecnologia, cores ciano e magenta.' },
  { id: 'horror', label: 'Terror', prompt: 'Sombrio, atmosférico, assustador, neblina, contraste alto, gótico.' },
];

const DesignCenter: React.FC<DesignCenterProps> = ({ book, onUpdateBook, addToast }) => {
  const [activeTab, setActiveTab] = useState<'cover' | 'metadata'>('cover');
  const [prompt, setPrompt] = useState(book.title);
  const [activePreset, setActivePreset] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedUrl, setGeneratedUrl] = useState(book.coverUrl);

  // Metadata states
  const [price, setPrice] = useState(book.price?.toString() || '');
  const [synopsis, setSynopsis] = useState(book.description || '');
  const [tags, setTags] = useState(book.tags?.join(', ') || '');

  const handleGenerate = async () => {
    setIsGenerating(true);
    addToast('Iniciando geração da capa com IA...', 'info');
    
    // Construct full prompt
    const presetPrompt = activePreset ? STYLE_PRESETS.find(p => p.id === activePreset)?.prompt : '';
    const fullPrompt = `${prompt}. ${presetPrompt}`;

    try {
      const url = await generateCoverImage(fullPrompt);
      if (url) {
        setGeneratedUrl(url);
        addToast('Capa gerada com sucesso!', 'success');
      } else {
        addToast('Não foi possível gerar a capa. Tente outro prompt.', 'error');
      }
    } catch (e: any) {
       addToast(e.message === "KEY_NOT_FOUND" ? "Chave de API não configurada." : "Erro na geração.", 'error');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSaveCover = () => {
    if (generatedUrl) {
      onUpdateBook({ ...book, coverUrl: generatedUrl });
      addToast('Nova capa aplicada ao livro.', 'success');
    }
  };

  const handlePublish = () => {
    onUpdateBook({
      ...book,
      status: 'published',
      price: parseFloat(price) || 0,
      description: synopsis,
      tags: tags.split(',').map(t => t.trim()).filter(t => t),
      coverUrl: generatedUrl // Ensure cover is saved on publish
    });
    addToast(`Parabéns! "${book.title}" foi publicado na loja.`, 'success');
  };

  return (
    <div className="h-full flex flex-col bg-slate-50">
      <div className="bg-white border-b border-slate-200 px-8 py-6 flex justify-between items-center shadow-sm">
        <div>
          <h2 className="text-2xl font-bold text-slate-900">Estúdio de Produção</h2>
          <p className="text-slate-500 text-sm">Prepare seu livro para o lançamento global.</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={() => setActiveTab('cover')}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'cover' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            1. Design da Capa
          </button>
          <div className="w-px h-8 bg-slate-200"></div>
          <button 
            onClick={() => setActiveTab('metadata')}
            className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${activeTab === 'metadata' ? 'bg-indigo-50 text-indigo-700' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            2. Detalhes & Preço
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8">
        <div className="max-w-5xl mx-auto">
          
          {activeTab === 'cover' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 animate-fade-in">
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-wide">Descrição da Imagem</label>
                  <textarea
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 h-32 mb-4 text-slate-700"
                    placeholder="Descreva a atmosfera, elementos centrais e cores..."
                  />
                  
                  <label className="block text-xs font-bold text-slate-400 mb-2 uppercase tracking-wide">Estilo Visual</label>
                  <div className="grid grid-cols-3 gap-2 mb-6">
                     {STYLE_PRESETS.map(preset => (
                        <button
                          key={preset.id}
                          onClick={() => setActivePreset(activePreset === preset.id ? null : preset.id)}
                          className={`px-3 py-2 rounded-lg text-xs font-bold transition-all border ${activePreset === preset.id ? 'bg-indigo-600 text-white border-indigo-600 shadow-md' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
                        >
                          {preset.label}
                        </button>
                     ))}
                  </div>

                  <button
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="w-full flex items-center justify-center gap-2 py-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition-all disabled:opacity-50 shadow-lg shadow-indigo-500/20 active:scale-95"
                  >
                    {isGenerating ? (
                       <>
                         <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                         <span>Criando Arte...</span>
                       </>
                    ) : (
                       <span>✨ Gerar Capa com IA</span>
                    )}
                  </button>
                </div>

                <div className="p-6 rounded-2xl bg-indigo-50 border border-indigo-100">
                  <h4 className="font-bold text-indigo-900 mb-2 text-sm">Dica de Design:</h4>
                  <p className="text-xs text-indigo-700 leading-relaxed">
                    A IA funciona melhor com descrições evocativas. Em vez de "um homem", tente "um guerreiro solitário em uma colina sob a luz do luar, estilo pintura a óleo".
                  </p>
                </div>
              </div>

              <div className="flex flex-col items-center">
                <div className="w-80 aspect-[2/3] bg-white rounded-lg shadow-2xl overflow-hidden border-[10px] border-white relative group">
                  {generatedUrl ? (
                    <img src={generatedUrl} alt="Capa Gerada" className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-slate-300 bg-slate-100">
                      <svg className="w-16 h-16 mb-4 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                      <span className="text-sm font-bold uppercase tracking-widest">Preview</span>
                    </div>
                  )}
                  {isGenerating && (
                    <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-10">
                      <div className="flex flex-col items-center">
                         <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4" />
                         <span className="text-xs font-bold text-indigo-600 animate-pulse">Pintando pixels...</span>
                      </div>
                    </div>
                  )}
                </div>
                {generatedUrl && generatedUrl !== book.coverUrl && (
                  <button onClick={handleSaveCover} className="mt-6 px-6 py-2 bg-white border border-slate-200 shadow-sm rounded-full text-sm font-bold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 transition-all">
                    Aplicar esta capa
                  </button>
                )}
              </div>
            </div>
          )}

          {activeTab === 'metadata' && (
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden animate-fade-in">
              <div className="p-8 grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="md:col-span-2 space-y-6">
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Sinopse (Contracapa)</label>
                    <textarea 
                      value={synopsis}
                      onChange={(e) => setSynopsis(e.target.value)}
                      className="w-full h-40 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Sobre o que é o seu livro? Escreva um texto chamativo..."
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Tags (Separadas por vírgula)</label>
                    <input 
                      value={tags}
                      onChange={(e) => setTags(e.target.value)}
                      className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="Fantasia, Magia, Dragões..."
                    />
                  </div>
                </div>

                <div className="bg-slate-50 p-6 rounded-xl border border-slate-100 h-fit">
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Preço de Venda (MT)</label>
                  <div className="relative mb-6">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold">MT</span>
                    <input 
                      type="number" 
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full pl-12 pr-4 py-4 text-2xl font-bold text-slate-900 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
                      placeholder="0.00"
                    />
                  </div>
                  
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                    <span>Royalties (70%)</span>
                    <span className="font-bold text-green-600">{(parseFloat(price || '0') * 0.7).toFixed(2)} MT</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-6 border-b border-slate-200 pb-4">
                    <span>Taxa da Plataforma</span>
                    <span>{(parseFloat(price || '0') * 0.3).toFixed(2)} MT</span>
                  </div>

                  <button 
                    onClick={handlePublish}
                    className={`w-full py-4 text-white rounded-xl font-bold shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2 ${book.status === 'published' ? 'bg-green-500 hover:bg-green-600' : 'bg-slate-900 hover:bg-indigo-600'}`}
                  >
                    {book.status === 'published' ? (
                      <>
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>
                        Publicado
                      </>
                    ) : (
                      <>
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"/></svg>
                        Publicar Agora
                      </>
                    )}
                  </button>
                  {book.status === 'published' && (
                    <p className="text-[10px] text-center text-slate-400 mt-3">
                      Seu livro já está disponível no Marketplace.
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DesignCenter;

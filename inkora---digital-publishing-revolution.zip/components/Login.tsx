
import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setTimeout(() => {
      onLogin({
        name: email.split('@')[0] || 'Escritor Inkora',
        email: email,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${email}`
      });
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen w-full flex bg-white relative overflow-hidden">
      
      {/* Left Side: Form */}
      <div className="w-full lg:w-[45%] flex flex-col justify-center items-center p-8 lg:p-16 z-20 bg-white shadow-2xl">
        <div className="w-full max-w-sm">
          <div className="flex items-center gap-3 mb-10 animate-fade-in">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black italic shadow-lg">I</div>
            <span className="text-2xl font-bold text-slate-900 tracking-tight">Inkora</span>
          </div>

          <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 tracking-tight mb-3 animate-fade-in delay-100">
            Criatividade <br/> sem limites.
          </h1>
          <p className="text-slate-500 text-lg mb-10 animate-fade-in delay-200">
            Acesse seu estúdio editorial v3.0.
          </p>

          <form onSubmit={handleSubmit} className="space-y-5 animate-fade-in delay-300">
            <div className="space-y-1.5 group">
              <label className="text-xs font-bold text-slate-900 uppercase">Email (Gmail)</label>
              <input 
                required
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@gmail.com"
                className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-4 py-3.5 focus:bg-white focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all outline-none font-medium placeholder:text-slate-400 group-hover:bg-white"
              />
            </div>
            <div className="space-y-1.5 group">
              <label className="text-xs font-bold text-slate-900 uppercase">Senha</label>
              <input 
                required
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-slate-50 border border-slate-200 text-slate-900 rounded-xl px-4 py-3.5 focus:bg-white focus:ring-2 focus:ring-indigo-600 focus:border-transparent transition-all outline-none font-medium placeholder:text-slate-400 group-hover:bg-white"
              />
            </div>
            
            <button 
              disabled={isLoading}
              type="submit" 
              className="w-full py-4 bg-slate-900 hover:bg-indigo-600 text-white rounded-xl font-bold text-base shadow-xl hover:shadow-2xl hover:shadow-indigo-600/30 transition-all active:scale-[0.98] mt-4 flex items-center justify-center group relative overflow-hidden"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                 <span className="relative z-10 flex items-center gap-2">
                   Entrar
                   <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                 </span>
              )}
            </button>
          </form>

          <div className="mt-8 animate-fade-in delay-500 flex justify-center">
             <button className="text-sm text-slate-400 hover:text-indigo-600 font-bold transition-colors">
               Esqueceu a senha?
             </button>
          </div>
        </div>
      </div>

      {/* Right Side: Animated Mesh Background */}
      <div className="hidden lg:block w-[55%] relative overflow-hidden gradient-mesh">
        <div className="absolute inset-0 bg-slate-900/10 z-10" />
        
        <div className="relative z-20 h-full flex flex-col justify-center items-center p-20 text-white text-center">
           <div className="animate-float">
              <div className="w-32 h-40 bg-white/10 backdrop-blur-xl border border-white/20 rounded-lg shadow-2xl mb-8 transform rotate-[-10deg] flex items-center justify-center">
                 <span className="font-serif text-4xl italic">Aa</span>
              </div>
           </div>
           
           <h2 className="text-5xl font-serif-display leading-tight mb-6 drop-shadow-lg">
             Histórias que <br/> <span className="italic text-indigo-300">transcendem.</span>
           </h2>
        </div>
      </div>
    </div>
  );
};

export default Login;


import React from 'react';
import { AppView, User } from '../types';

interface SidebarProps {
  currentView: AppView;
  setView: (view: AppView) => void;
  onCreateBook: () => void;
  user: User;
  onOpenConfig?: () => void;
  isOpen: boolean; // Controls visibility
  onClose: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, onCreateBook, user, onOpenConfig, isOpen, onClose }) => {
  const navItems = [
    { id: AppView.LIBRARY, label: 'Biblioteca', icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10' },
    { id: AppView.WRITER, label: 'Manuscrito', icon: 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z' },
    { id: AppView.DESIGN, label: 'Design Hub', icon: 'M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z' },
    { id: AppView.STORE, label: 'Marketplace', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
    { id: AppView.DASHBOARD, label: 'Vendas & Métrica', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
  ];

  return (
    <>
      {/* Overlay for mobile/when open */}
      <div 
        className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-40 transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />

      <aside 
        className={`fixed top-0 left-0 h-full bg-slate-950 text-slate-300 flex flex-col z-50 shadow-2xl transition-transform duration-300 ease-in-out border-r border-white/5 ${isOpen ? 'translate-x-0' : '-translate-x-full'}`}
        style={{ width: 'var(--sidebar-width)' }}
      >
        <div className="p-8 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-lg italic shadow-lg shrink-0">I</div>
            <span>Inkora</span>
          </h1>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => { setView(item.id); onClose(); }}
              style={{ borderRadius: 'var(--ui-radius)' }}
              className={`w-full flex items-center gap-4 px-5 py-4 transition-all duration-300 ${
                currentView === item.id 
                ? 'bg-indigo-600 text-white shadow-lg translate-x-1' 
                : 'hover:bg-white/5 hover:text-white'
              }`}
            >
              <svg className="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} /></svg>
              <span className="font-bold text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-6 mt-auto space-y-6">
          <button 
            onClick={() => { onCreateBook(); onClose(); }}
            style={{ borderRadius: 'var(--ui-radius)' }}
            className="w-full flex items-center justify-center gap-2 py-4 bg-white/5 hover:bg-white/10 text-indigo-400 font-black border border-indigo-500/20 transition-all"
          >
            <span>+ Novo Projeto</span>
          </button>

          {user && (
            <div className="p-4 bg-white/5 flex items-center gap-4 border border-white/5 rounded-xl">
               <img src={user.avatar} className="w-10 h-10 rounded-full border-2 border-indigo-500/50" alt={user.name} />
               <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-white truncate">{user.name}</p>
                  <p className="text-[10px] text-slate-500 uppercase font-black">Escritor Pro</p>
               </div>
            </div>
          )}
        </div>
      </aside>
    </>
  );
};

export default Sidebar;

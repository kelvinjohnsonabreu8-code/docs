
import React, { useState } from 'react';
import { Book } from '../types';

interface MarketplaceProps {
  books: Book[];
}

const Marketplace: React.FC<MarketplaceProps> = ({ books }) => {
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [paymentStep, setPaymentStep] = useState<'idle' | 'method' | 'processing' | 'success'>('idle');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [selectedMethod, setSelectedMethod] = useState<'mpesa' | 'emola' | 'card' | 'paypal' | null>(null);

  const handlePurchase = (book: Book) => {
    setSelectedBook(book);
    setPaymentStep('method');
    setSelectedMethod(null);
  };

  const processPayment = () => {
    // If M-Pesa or e-Mola require phone, others might require different validation
    if ((selectedMethod === 'mpesa' || selectedMethod === 'emola') && !phoneNumber) return;
    
    setPaymentStep('processing');
    setTimeout(() => {
      setPaymentStep('success');
    }, 4000); // Increased time to show off the new animation
  };

  return (
    <div className="p-8 max-w-7xl mx-auto min-h-full">
      <div className="bg-indigo-600 rounded-[2.5rem] p-16 text-white mb-16 relative overflow-hidden shadow-2xl shadow-indigo-600/30">
        <div className="absolute top-0 right-0 w-[40%] h-full bg-white/10 transform skew-x-12 -translate-y-12" />
        <div className="relative z-10 max-w-3xl">
          <span className="inline-block px-4 py-1 bg-white/20 rounded-full text-xs font-bold uppercase tracking-widest mb-6">Novidades do Mês</span>
          <h2 className="text-6xl font-serif-display mb-6 leading-tight">Literatura local, <br/><span className="italic text-indigo-200">alcance global.</span></h2>
          <p className="text-indigo-100 text-xl mb-10 leading-relaxed max-w-xl">Descubra novos mundos, compre por capítulo ou o livro completo usando M-Pesa e e-Mola. Apoie o talento de Moçambique.</p>
          <div className="flex gap-4">
            <button className="px-10 py-4 bg-white text-indigo-600 rounded-2xl font-black hover:bg-indigo-50 transition-all shadow-xl active:scale-95">Explorar Livraria</button>
            <button className="px-10 py-4 bg-indigo-500/50 border border-white/30 text-white rounded-2xl font-black hover:bg-indigo-500/70 transition-all">Ver Categorias</button>
          </div>
        </div>
      </div>

      <div className="mb-20">
        <div className="flex items-center justify-between mb-10">
          <h3 className="text-3xl font-bold text-slate-900">Em Destaque</h3>
          <div className="flex gap-2">
            <button className="p-3 rounded-full border border-slate-200 hover:bg-white hover:shadow-md transition-all">
              <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
            </button>
            <button className="p-3 rounded-full border border-slate-200 hover:bg-white hover:shadow-md transition-all">
              <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"/></svg>
            </button>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-8">
          {books.map(book => (
            <div key={book.id} className="group bg-white rounded-[2rem] border border-slate-100 p-5 hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2">
              <div className="aspect-[3/4] overflow-hidden rounded-[1.5rem] mb-6 relative">
                 <img src={book.coverUrl} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt={book.title} />
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                    <button 
                      onClick={() => handlePurchase(book)}
                      className="w-full py-3 bg-white text-slate-900 rounded-xl font-bold text-sm shadow-xl active:scale-95 transition-all"
                    >
                      Ler Agora
                    </button>
                 </div>
              </div>
              <h4 className="font-bold text-slate-900 truncate text-lg">{book.title}</h4>
              <p className="text-xs text-slate-400 mb-6 font-medium">por {book.author}</p>
              <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                <span className="text-indigo-600 font-black text-xl">{book.price ? `${book.price} MT` : 'Grátis'}</span>
                <button 
                   onClick={() => handlePurchase(book)}
                   className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl hover:bg-indigo-600 hover:text-white transition-all shadow-sm"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" /></svg>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Payment Modal */}
      {selectedBook && paymentStep !== 'idle' && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md flex items-center justify-center z-[100] p-4 animate-fade-in">
          <div className="bg-white w-full max-w-lg rounded-[2.5rem] p-10 relative shadow-2xl overflow-hidden">
             {paymentStep === 'method' && (
               <div className="animate-slide-in">
                 <h3 className="text-3xl font-bold text-slate-900 mb-2">Quase lá!</h3>
                 <p className="text-slate-500 mb-8">Escolha como deseja adquirir <span className="text-indigo-600 font-bold">"{selectedBook.title}"</span>.</p>
                 
                 <div className="grid grid-cols-2 gap-3 mb-8">
                    {/* M-Pesa */}
                    <button 
                      onClick={() => setSelectedMethod('mpesa')} 
                      className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all ${selectedMethod === 'mpesa' ? 'border-red-500 bg-red-50 text-red-700' : 'border-slate-100 hover:border-slate-300'}`}
                    >
                      <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center text-white font-black italic">M</div>
                      <span className="text-xs font-bold">M-Pesa</span>
                    </button>

                    {/* e-Mola */}
                    <button 
                      onClick={() => setSelectedMethod('emola')} 
                      className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all ${selectedMethod === 'emola' ? 'border-orange-500 bg-orange-50 text-orange-700' : 'border-slate-100 hover:border-slate-300'}`}
                    >
                      <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center text-white font-black">e</div>
                      <span className="text-xs font-bold">e-Mola</span>
                    </button>

                    {/* Card */}
                    <button 
                      onClick={() => setSelectedMethod('card')} 
                      className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all ${selectedMethod === 'card' ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-slate-100 hover:border-slate-300'}`}
                    >
                      <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white">
                         <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/></svg>
                      </div>
                      <span className="text-xs font-bold">Cartão</span>
                    </button>

                     {/* PayPal */}
                     <button 
                      onClick={() => setSelectedMethod('paypal')} 
                      className={`p-4 border-2 rounded-2xl flex flex-col items-center justify-center gap-2 transition-all ${selectedMethod === 'paypal' ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-slate-100 hover:border-slate-300'}`}
                    >
                      <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center text-white font-bold text-sm">P</div>
                      <span className="text-xs font-bold">PayPal</span>
                    </button>
                 </div>

                 {selectedMethod && (
                   <div className="space-y-4 animate-fade-in">
                      {/* Mobile Money Inputs */}
                      {(selectedMethod === 'mpesa' || selectedMethod === 'emola') && (
                        <div className="space-y-1">
                          <label className="text-[10px] font-black text-slate-400 uppercase px-1">Número de Telemóvel</label>
                          <input 
                            type="tel" 
                            placeholder="84 / 85 ..." 
                            value={phoneNumber}
                            onChange={(e) => setPhoneNumber(e.target.value)}
                            className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                        </div>
                      )}

                       {/* Card Inputs Mockup */}
                       {selectedMethod === 'card' && (
                         <div className="space-y-3 p-4 bg-slate-50 rounded-xl border border-slate-200">
                             <input className="w-full p-3 bg-white rounded border border-slate-200 text-sm" placeholder="Número do Cartão" />
                             <div className="flex gap-3">
                               <input className="w-1/2 p-3 bg-white rounded border border-slate-200 text-sm" placeholder="MM/AA" />
                               <input className="w-1/2 p-3 bg-white rounded border border-slate-200 text-sm" placeholder="CVC" />
                             </div>
                         </div>
                       )}

                      <button 
                        onClick={processPayment}
                        disabled={(selectedMethod === 'mpesa' || selectedMethod === 'emola') && !phoneNumber}
                        className="w-full py-5 bg-slate-900 text-white rounded-2xl font-black shadow-xl disabled:opacity-30 transition-all active:scale-95"
                      >
                        Pagar {selectedBook.price} MT
                      </button>
                   </div>
                 )}
               </div>
             )}

             {paymentStep === 'processing' && (
               <div className="text-center py-10 animate-fade-in flex flex-col items-center">
                  {/* MAGICAL BOOK ANIMATION */}
                  <div className="book-loader mb-8">
                    <div className="book-cover"></div>
                    <div className="book-page"></div>
                    <div className="book-page"></div>
                    <div className="book-page"></div>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Imprimindo sua Cópia...</h3>
                  <p className="text-slate-500">
                    {(selectedMethod === 'mpesa' || selectedMethod === 'emola') ? 'Verifique seu telemóvel para o PIN.' : 'Autenticando transação segura.'}
                  </p>
               </div>
             )}

             {paymentStep === 'success' && (
               <div className="text-center py-10 animate-fade-in">
                  <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
                     <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7"/></svg>
                  </div>
                  <h3 className="text-3xl font-bold text-slate-900 mb-2">Sucesso!</h3>
                  <p className="text-slate-500 mb-10">O livro já está disponível na sua biblioteca. Boa leitura!</p>
                  <button 
                    onClick={() => setPaymentStep('idle')}
                    className="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black shadow-xl"
                  >
                    Começar a Ler
                  </button>
               </div>
             )}

             <button 
                onClick={() => setPaymentStep('idle')} 
                className="absolute top-6 right-6 text-slate-300 hover:text-slate-600 transition-colors"
             >
               <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
             </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Marketplace;

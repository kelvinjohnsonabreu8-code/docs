
import React from 'react';
import { Book } from '../types';

interface LibraryProps {
  books: Book[];
  onSelectBook: (id: string) => void;
}

const Library: React.FC<LibraryProps> = ({ books, onSelectBook }) => {
  return (
    <div className="p-8 max-w-6xl mx-auto">
      <div className="flex justify-between items-end mb-8">
        <div>
          <h2 className="text-3xl font-bold text-slate-900 mb-2">Sua Biblioteca</h2>
          <p className="text-slate-500">Gerencie seus projetos literários e acompanhe seu progresso.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {books.map((book) => (
          <div 
            key={book.id}
            onClick={() => onSelectBook(book.id)}
            className="group bg-white rounded-2xl shadow-sm hover:shadow-xl border border-slate-200 overflow-hidden transition-all cursor-pointer transform hover:-translate-y-1"
          >
            <div className="aspect-[2/3] bg-slate-100 relative overflow-hidden">
              {book.coverUrl ? (
                <img src={book.coverUrl} alt={book.title} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-indigo-50 to-slate-100">
                  <span className="text-slate-400 font-medium">Sem Capa</span>
                </div>
              )}
              <div className="absolute top-3 right-3">
                <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  book.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                }`}>
                  {book.status === 'published' ? 'Publicado' : 'Rascunho'}
                </span>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-slate-900 truncate mb-1">{book.title}</h3>
              <p className="text-xs text-slate-500 truncate mb-3">por {book.author}</p>
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-slate-400 font-semibold uppercase">{book.category}</span>
                <span className="text-[10px] text-slate-400">{book.chapters.length} Capítulos</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Library;

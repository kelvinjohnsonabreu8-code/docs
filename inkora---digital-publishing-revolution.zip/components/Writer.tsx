
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Book, Chapter, BookSettings, ToastType, AtmosphereType } from '../types';
import { improveText, suggestPlot, generateCharacterProfile, getSynonyms, generateNames, getEmotionDetails } from '../services/geminiService';

interface WriterProps {
  book: Book;
  onUpdateBook: (book: Book) => void;
  addToast: (message: string, type: ToastType) => void;
}

const DEFAULT_SETTINGS: BookSettings = {
  fontFamily: 'Merriweather',
  fontSize: '18px',
  lineHeight: '1.8',
  pageColor: '#ffffff',
  textColor: '#1e293b',
  pageSize: 'a4',
  margins: 'normal',
  textAlign: 'left',
  atmosphere: 'none'
};

const FONT_OPTIONS = [
  { name: 'Merriweather', category: 'Serif' },
  { name: 'Lora', category: 'Serif' },
  { name: 'Crimson Text', category: 'Serif' },
  { name: 'Inter', category: 'Sans' },
  { name: 'Roboto', category: 'Sans' },
  { name: 'Oswald', category: 'Display' },
  { name: 'Dancing Script', category: 'Script' },
  { name: 'JetBrains Mono', category: 'Mono' },
];

const Writer: React.FC<WriterProps> = ({ book, onUpdateBook, addToast }) => {
  const [activeChapterId, setActiveChapterId] = useState<string>(book.chapters[0]?.id || '');
  const [settings, setSettings] = useState<BookSettings>(book.settings || DEFAULT_SETTINGS);
  
  // UI States
  const [isDistractionFree, setIsDistractionFree] = useState(false);
  const [showFontPicker, setShowFontPicker] = useState(false);
  
  // Tabs: 'texto' | 'layout' | 'ferramentas' | 'ia'
  const [activeToolTab, setActiveToolTab] = useState<'texto' | 'layout' | 'ferramentas' | 'ia'>('texto');
  const [showNotesPanel, setShowNotesPanel] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'unsaved'>('saved');
  
  // Movable Toolbar State
  const [toolbarPos, setToolbarPos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [orientation, setOrientation] = useState<'horizontal' | 'vertical'>('horizontal');
  
  // Refs for robust dragging (avoids closure staleness)
  const dragRef = useRef<{ isDragging: boolean; startX: number; startY: number; initialLeft: number; initialTop: number } | null>(null);

  // --- SUPER TOOLS STATES ---
  const [undoStack, setUndoStack] = useState<string[]>([]);
  const [redoStack, setRedoStack] = useState<string[]>([]);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [zoomLevel, setZoomLevel] = useState(1); 
  const [showSnapshots, setShowSnapshots] = useState(false);
  const [snapshots, setSnapshots] = useState<{time: string, text: string}[]>([]);
  
  // Tools & AI
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [zenMode, setZenMode] = useState(false);
  const [timerActive, setTimerActive] = useState(false);
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [showAIHelp, setShowAIHelp] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState('');
  const [isImproving, setIsImproving] = useState(false);

  const editorRef = useRef<HTMLTextAreaElement>(null);
  const saveTimeoutRef = useRef<any>(null);
  const recognitionRef = useRef<any>(null);

  const activeChapter = book.chapters.find(c => c.id === activeChapterId) || book.chapters[0];
  const [localContent, setLocalContent] = useState(activeChapter.content);
  const [localTitle, setLocalTitle] = useState(activeChapter.title);

  useEffect(() => {
    setLocalContent(activeChapter.content);
    setLocalTitle(activeChapter.title);
    setUndoStack([]);
    setRedoStack([]);
  }, [activeChapterId]);

  useEffect(() => {
    // Initial Center Position
    const centerX = window.innerWidth / 2 - 250; 
    setToolbarPos({ x: Math.max(0, centerX), y: window.innerHeight - 250 });
  }, []);

  useEffect(() => {
    if (JSON.stringify(book.settings) !== JSON.stringify(settings)) {
      onUpdateBook({ ...book, settings });
    }
  }, [settings]);

  // --- ROBUST DRAG LOGIC (MOUSE & TOUCH) ---
  const handleDragStart = (e: React.MouseEvent | React.TouchEvent) => {
    // Prevent drag if clicking a button, input, or textarea
    const target = e.target as HTMLElement;
    if (target.closest('button') || target.closest('input') || target.closest('textarea')) {
      return;
    }
    
    // Only prevent default if it's not a touch event (to allow scrolling if needed, though here we want to drag)
    if (!('touches' in e)) {
      e.preventDefault();
    }

    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;

    dragRef.current = {
      isDragging: true,
      startX: clientX,
      startY: clientY,
      initialLeft: toolbarPos.x,
      initialTop: toolbarPos.y
    };
    
    setIsDragging(true);

    // Attach global listeners
    window.addEventListener('mousemove', handleDragMove);
    window.addEventListener('mouseup', handleDragEnd);
    window.addEventListener('touchmove', handleDragMove, { passive: false });
    window.addEventListener('touchend', handleDragEnd);
  };

  const handleDragMove = useCallback((e: MouseEvent | TouchEvent) => {
    if (!dragRef.current?.isDragging) return;

    e.preventDefault(); // Stop scrolling while dragging toolbar

    const clientX = 'touches' in e ? (e as TouchEvent).touches[0].clientX : (e as MouseEvent).clientX;
    const clientY = 'touches' in e ? (e as TouchEvent).touches[0].clientY : (e as MouseEvent).clientY;

    const deltaX = clientX - dragRef.current.startX;
    const deltaY = clientY - dragRef.current.startY;

    setToolbarPos({
      x: dragRef.current.initialLeft + deltaX,
      y: dragRef.current.initialTop + deltaY
    });
  }, []);

  const handleDragEnd = useCallback(() => {
    dragRef.current = null;
    setIsDragging(false);
    
    // Cleanup
    window.removeEventListener('mousemove', handleDragMove);
    window.removeEventListener('mouseup', handleDragEnd);
    window.removeEventListener('touchmove', handleDragMove);
    window.removeEventListener('touchend', handleDragEnd);
  }, [handleDragMove]);

  // Ensure cleanup on unmount
  useEffect(() => {
    return () => {
      window.removeEventListener('mousemove', handleDragMove);
      window.removeEventListener('mouseup', handleDragEnd);
      window.removeEventListener('touchmove', handleDragMove);
      window.removeEventListener('touchend', handleDragEnd);
    };
  }, [handleDragMove, handleDragEnd]);


  // --- CONTENT HANDLING ---
  const updateContent = (newContent: string, saveToHistory = true) => {
    if (saveToHistory) {
      setUndoStack(prev => [...prev, localContent].slice(-20)); 
      setRedoStack([]); 
    }
    setLocalContent(newContent);
    setSaveStatus('saving');
    
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      const updatedChapters = book.chapters.map(c => 
        c.id === activeChapter.id ? { ...c, content: newContent, title: localTitle } : c
      );
      onUpdateBook({ ...book, chapters: updatedChapters });
      setSaveStatus('saved');
    }, 1500);
  };

  const handleTitleChange = (newTitle: string) => {
    setLocalTitle(newTitle);
    setSaveStatus('saving');
    if (saveTimeoutRef.current) clearTimeout(saveTimeoutRef.current);
    saveTimeoutRef.current = setTimeout(() => {
      const updatedChapters = book.chapters.map(c => 
        c.id === activeChapter.id ? { ...c, content: localContent, title: newTitle } : c
      );
      onUpdateBook({ ...book, chapters: updatedChapters });
      setSaveStatus('saved');
    }, 1500);
  };

  // --- TOOLS IMPL ---
  const handleUndo = () => {
    if (undoStack.length === 0) return;
    const previous = undoStack[undoStack.length - 1];
    setRedoStack(prev => [localContent, ...prev]);
    setUndoStack(prev => prev.slice(0, -1));
    updateContent(previous, false);
    addToast('Desfeito', 'info');
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[0];
    setUndoStack(prev => [...prev, localContent]);
    setRedoStack(prev => prev.slice(1));
    updateContent(next, false);
    addToast('Refeito', 'info');
  };

  const handleFindReplace = () => {
    if (!findText) return;
    const newContent = localContent.replaceAll(findText, replaceText);
    const count = localContent.split(findText).length - 1;
    if (newContent !== localContent) {
      updateContent(newContent);
      addToast(`${count} substituídos.`, 'success');
    } else {
      addToast('Não encontrado.', 'error');
    }
  };

  const changeCase = (type: 'upper' | 'lower' | 'title') => {
    const textarea = editorRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selection = localContent.substring(start, end);
    if (!selection) return addToast('Selecione texto.', 'info');
    let transformed = selection;
    if (type === 'upper') transformed = selection.toUpperCase();
    if (type === 'lower') transformed = selection.toLowerCase();
    if (type === 'title') transformed = selection.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());
    updateContent(localContent.substring(0, start) + transformed + localContent.substring(end));
  };

  const insertMarkdown = (marker: string) => {
    const textarea = editorRef.current;
    if (!textarea) return;
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selection = localContent.substring(start, end);
    updateContent(localContent.substring(0, start) + `${marker}${selection}${marker}` + localContent.substring(end));
  };

  const clearFormatting = () => {
     let clean = localContent.replace(/\*\*/g, '').replace(/\*/g, '').replace(/  +/g, ' ');
     updateContent(clean);
     addToast('Formatação limpa.', 'info');
  };

  const adjustZoom = (delta: number) => setZoomLevel(prev => Math.min(Math.max(0.5, prev + delta), 2));
  const takeSnapshot = () => {
    setSnapshots(prev => [{ time: new Date().toLocaleTimeString(), text: localContent }, ...prev].slice(0, 5));
    addToast('Snapshot salvo.', 'success');
  };

  const toggleDictation = () => {
    if (isListening) { if (recognitionRef.current) recognitionRef.current.stop(); setIsListening(false); return; }
    if (!('webkitSpeechRecognition' in window)) { addToast("Incompatível.", 'error'); return; }
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.continuous = true; recognition.interimResults = true; recognition.lang = 'pt-BR';
    recognition.onresult = (e: any) => {
      let final = ''; for (let i = e.resultIndex; i < e.results.length; ++i) if (e.results[i].isFinal) final += e.results[i][0].transcript;
      if (final) updateContent(localContent + ' ' + final);
    };
    recognition.start(); recognitionRef.current = recognition; setIsListening(true); addToast("Ouvindo...", 'success');
  };

  const toggleTTS = () => {
    if (isSpeaking) { window.speechSynthesis.cancel(); setIsSpeaking(false); } 
    else { const u = new SpeechSynthesisUtterance(localContent); u.lang = 'pt-BR'; u.onend = () => setIsSpeaking(false); window.speechSynthesis.speak(u); setIsSpeaking(true); }
  };

  // AI & Vibes
  const handleImprove = async () => { setIsImproving(true); addToast('IA pensando...', 'info'); try { const r = await improveText(localContent); if(r) { setAiSuggestion(r); setShowAIHelp(true); } } catch(e) { addToast('Erro IA', 'error'); } setIsImproving(false); };
  const handleSynonyms = async () => { const s = window.getSelection()?.toString(); if(!s) return addToast('Selecione palavra.', 'info'); const res = await getSynonyms(s); if(res.length) { setAiSuggestion(`Sinônimos de "${s}": ${res.join(', ')}`); setShowAIHelp(true); } };
  const handleCharacter = async () => { addToast('Gerando...', 'info'); const p = await generateCharacterProfile(book.category); if(p) { setAiSuggestion(p); setShowAIHelp(true); } };

  // Timer
  useEffect(() => {
    let interval: any;
    if (timerActive && timeLeft > 0) interval = setInterval(() => setTimeLeft(p => p - 1), 1000);
    else if (timeLeft === 0 && timerActive) { setTimerActive(false); addToast('Tempo esgotado!', 'success'); }
    return () => clearInterval(interval);
  }, [timerActive, timeLeft]);
  const formatTime = (s: number) => `${Math.floor(s/60).toString().padStart(2,'0')}:${(s%60).toString().padStart(2,'0')}`;

  const isVertical = orientation === 'vertical';
  const wordCount = localContent.split(/\s+/).filter(w => w !== '').length;

  return (
    <div className="flex h-full bg-[#e2e8f0] relative overflow-hidden">
      <div className="flex-1 flex flex-col relative h-full">
        
        {!isDistractionFree && (
          <div className="h-8 flex items-center justify-between px-4 bg-white border-b border-slate-200/60 z-30 shadow-sm">
             <div className="flex gap-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                <span>{wordCount} Palavras</span>
                <span>{localContent.length} Caracteres</span>
             </div>
             <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                {saveStatus === 'saving' && <span className="animate-pulse text-indigo-500">Salvando...</span>}
                {saveStatus === 'saved' && <span className="text-green-500">Salvo</span>}
             </div>
          </div>
        )}

        {/* --- ULTIMATE TOOLBAR (DRAGGABLE) --- */}
        {!isDistractionFree && (
          <div 
            onMouseDown={handleDragStart}
            onTouchStart={handleDragStart}
            className={`fixed z-[9999] transition-all duration-75 ease-out ${isDragging ? 'scale-105 cursor-grabbing opacity-95' : 'cursor-grab'} 
              bg-slate-900/95 backdrop-blur-md rounded-xl shadow-2xl shadow-indigo-900/30 border border-slate-700/50 p-1.5 flex 
              ${isVertical ? 'flex-col max-h-[80vh] overflow-y-auto w-16' : 'flex-row items-center'} 
              gap-2 select-none text-slate-300 touch-none`}
            style={{ left: `${toolbarPos.x}px`, top: `${toolbarPos.y}px` }}
          >
            {/* GRIP HANDLE */}
            <div className={`flex items-center justify-center text-slate-500 ${isVertical ? 'w-full h-4 mb-1' : 'w-4 h-full mr-1'}`}>
               <div className={`bg-slate-600 rounded-full ${isVertical ? 'w-8 h-1' : 'w-1 h-8'}`} />
            </div>

            {/* Navigation Tabs */}
            <div className={`flex bg-slate-800 p-1 rounded-lg ${isVertical ? 'flex-col gap-1' : 'mr-2'}`}>
              <button onClick={() => setActiveToolTab('texto')} className={`p-2 rounded hover:bg-slate-700 ${activeToolTab === 'texto' ? 'bg-indigo-600 text-white' : ''}`} title="Texto">¶</button>
              <button onClick={() => setActiveToolTab('layout')} className={`p-2 rounded hover:bg-slate-700 ${activeToolTab === 'layout' ? 'bg-indigo-600 text-white' : ''}`} title="Layout">📄</button>
              <button onClick={() => setActiveToolTab('ferramentas')} className={`p-2 rounded hover:bg-slate-700 ${activeToolTab === 'ferramentas' ? 'bg-indigo-600 text-white' : ''}`} title="Ferramentas">🛠️</button>
              <button onClick={() => setActiveToolTab('ia')} className={`p-2 rounded hover:bg-slate-700 ${activeToolTab === 'ia' ? 'bg-indigo-600 text-white' : 'text-indigo-400'}`} title="IA e Vibe">✨</button>
            </div>

            <div className={`bg-slate-700 ${isVertical ? 'w-full h-px' : 'w-px h-8'}`}></div>

            {/* --- TAB: TEXTO --- */}
            {activeToolTab === 'texto' && (
              <div className={`flex gap-1 ${isVertical ? 'flex-col' : 'items-center'}`}>
                 <button onClick={() => setShowFontPicker(!showFontPicker)} className="p-2 hover:bg-slate-700 rounded text-[10px] w-20 truncate border border-slate-600">{settings.fontFamily}</button>
                 {showFontPicker && (
                    <div className="absolute top-full mt-2 bg-white text-slate-800 p-2 rounded-xl shadow-xl w-40 z-50">
                       {FONT_OPTIONS.map(f => <div key={f.name} onClick={() => setSettings({...settings, fontFamily: f.name})} className="p-2 hover:bg-slate-100 text-xs cursor-pointer">{f.name}</div>)}
                    </div>
                 )}
                 <div className="flex bg-slate-800 rounded">
                    <button onClick={() => setSettings({...settings, fontSize: (parseInt(settings.fontSize)-1)+'px'})} className="px-2 text-xs hover:bg-slate-700">-</button>
                    <span className="px-1 text-[10px] flex items-center">{settings.fontSize}</span>
                    <button onClick={() => setSettings({...settings, fontSize: (parseInt(settings.fontSize)+1)+'px'})} className="px-2 text-xs hover:bg-slate-700">+</button>
                 </div>
                 <div className={`bg-slate-700 w-px h-6 mx-1`}></div>
                 <button onClick={() => insertMarkdown('**')} className="p-2 font-bold hover:bg-slate-700 rounded text-xs">B</button>
                 <button onClick={() => insertMarkdown('*')} className="p-2 italic hover:bg-slate-700 rounded text-xs">I</button>
                 <button onClick={() => setSettings({...settings, textAlign: 'left'})} className={`p-2 rounded ${settings.textAlign==='left'?'bg-slate-700':''}`}>L</button>
                 <button onClick={() => setSettings({...settings, textAlign: 'justify'})} className={`p-2 rounded ${settings.textAlign==='justify'?'bg-slate-700':''}`}>J</button>
                 <button onClick={() => changeCase('upper')} className="p-2 text-[10px] hover:bg-slate-700 rounded">AA</button>
                 <button onClick={clearFormatting} className="p-2 hover:bg-slate-700 rounded" title="Limpar">🧹</button>
              </div>
            )}

            {/* --- TAB: LAYOUT --- */}
            {activeToolTab === 'layout' && (
               <div className="flex gap-1 items-center">
                  <button onClick={() => setSettings({...settings, pageSize: settings.pageSize==='a4'?'a5':'a4'})} className="p-2 text-[10px] font-bold bg-slate-800 rounded">{settings.pageSize.toUpperCase()}</button>
                  <button onClick={() => setSettings({...settings, margins: settings.margins==='normal'?'wide':'normal'})} className="p-2 text-[10px] bg-slate-800 rounded">Margem</button>
                  <div className="flex gap-1 bg-slate-800 p-1 rounded">
                     <button onClick={() => setSettings({...settings, pageColor: '#fff', textColor: '#1e293b'})} className="w-4 h-4 rounded-full bg-white"></button>
                     <button onClick={() => setSettings({...settings, pageColor: '#fdf6e3', textColor: '#5c6370'})} className="w-4 h-4 rounded-full bg-[#fdf6e3]"></button>
                     <button onClick={() => setSettings({...settings, pageColor: '#1a1a1a', textColor: '#ccc'})} className="w-4 h-4 rounded-full bg-slate-900 border border-slate-600"></button>
                  </div>
                  <div className={`bg-slate-700 w-px h-6 mx-1`}></div>
                  <button onClick={() => adjustZoom(-0.1)} className="p-2 hover:bg-slate-700 text-xs">-</button>
                  <span className="text-[10px] w-8 text-center">{Math.round(zoomLevel*100)}%</span>
                  <button onClick={() => adjustZoom(0.1)} className="p-2 hover:bg-slate-700 text-xs">+</button>
               </div>
            )}

            {/* --- TAB: FERRAMENTAS --- */}
            {activeToolTab === 'ferramentas' && (
               <div className="flex gap-1">
                  <button onClick={handleUndo} className="p-2 hover:bg-slate-700 rounded disabled:opacity-30" disabled={!undoStack.length}>↩️</button>
                  <button onClick={handleRedo} className="p-2 hover:bg-slate-700 rounded disabled:opacity-30" disabled={!redoStack.length}>↪️</button>
                  <button onClick={() => setShowFindReplace(!showFindReplace)} className={`p-2 hover:bg-slate-700 rounded ${showFindReplace?'bg-slate-700':''}`}>🔍</button>
                  <button onClick={takeSnapshot} className="p-2 hover:bg-slate-700 rounded">📸</button>
                  <button onClick={() => setShowSnapshots(!showSnapshots)} className="p-2 text-[10px] hover:bg-slate-700 font-bold">HIST</button>
                  <div className={`bg-slate-700 w-px h-6 mx-1`}></div>
                  <button onClick={toggleDictation} className={`p-2 hover:bg-slate-700 rounded ${isListening?'text-red-500 animate-pulse':''}`}>🎙️</button>
                  <button onClick={toggleTTS} className={`p-2 hover:bg-slate-700 rounded ${isSpeaking?'text-green-500':''}`}>🗣️</button>
                  <button onClick={() => setZenMode(!zenMode)} className={`p-2 hover:bg-slate-700 rounded ${zenMode?'text-indigo-400':''}`}>🎯</button>
                  <button onClick={() => setTimerActive(!timerActive)} className={`p-2 text-[10px] font-mono border border-slate-700 rounded ${timerActive?'text-red-400':''}`}>{formatTime(timeLeft)}</button>
               </div>
            )}

            {/* --- TAB: IA & VIBE --- */}
            {activeToolTab === 'ia' && (
               <div className="flex gap-1">
                  <button onClick={handleImprove} className="p-2 text-[10px] font-bold bg-indigo-600 rounded hover:bg-indigo-500 text-white">Polir</button>
                  <button onClick={handleSynonyms} className="p-2 hover:bg-slate-700 rounded" title="Sinônimos">📚</button>
                  <button onClick={async () => { const n = await generateNames(book.category); if(n[0]) updateContent(localContent+' '+n[0]); }} className="p-2 hover:bg-slate-700 rounded" title="Nome">👤</button>
                  <button onClick={handleCharacter} className="p-2 hover:bg-slate-700 rounded" title="Personagem">🎭</button>
                  <button onClick={async () => { const s = await suggestPlot(localContent); if(s){ setAiSuggestion(s); setShowAIHelp(true); }}} className="p-2 hover:bg-slate-700 rounded" title="Plot">💡</button>
                  <div className={`bg-slate-700 w-px h-6 mx-1`}></div>
                  {['rain','cafe','fireplace'].map(s => (
                     <button key={s} onClick={() => setSettings({...settings, atmosphere: settings.atmosphere===s?'none':s as any})} className={`p-2 text-[10px] uppercase rounded ${settings.atmosphere===s?'bg-pink-600 text-white':'hover:bg-slate-700'}`}>{s.substring(0,2)}</button>
                  ))}
               </div>
            )}

            <div className={`bg-slate-700 ${isVertical ? 'w-full h-px' : 'w-px h-8'}`}></div>
            <button onClick={() => setOrientation(orientation === 'horizontal' ? 'vertical' : 'horizontal')} className="p-2 hover:bg-slate-700 rounded text-xs">🔄</button>
          </div>
        )}

        {/* --- MODALS --- */}
        {showFindReplace && (
           <div className="fixed top-24 left-1/2 -translate-x-1/2 bg-white shadow-2xl p-4 rounded-xl border border-slate-200 z-50 flex gap-2 animate-slide-in text-sm">
              <input value={findText} onChange={e => setFindText(e.target.value)} placeholder="Localizar..." className="border p-2 rounded" />
              <input value={replaceText} onChange={e => setReplaceText(e.target.value)} placeholder="Substituir..." className="border p-2 rounded" />
              <button onClick={handleFindReplace} className="bg-indigo-600 text-white px-4 rounded font-bold">OK</button>
              <button onClick={() => setShowFindReplace(false)} className="text-slate-400 font-bold px-2">X</button>
           </div>
        )}

        {showSnapshots && (
           <div className="fixed right-4 top-32 w-64 bg-white shadow-2xl rounded-xl border border-slate-200 z-[9990] p-4 animate-slide-in">
              <h4 className="font-bold text-slate-900 mb-4 text-xs uppercase">Histórico de Versões</h4>
              <div className="space-y-2">
                 {snapshots.map((s, i) => (
                    <div key={i} className="p-3 bg-slate-50 rounded hover:bg-indigo-50 cursor-pointer border border-slate-100" onClick={() => { updateContent(s.text); setShowSnapshots(false); addToast('Versão restaurada', 'success'); }}>
                       <div className="text-xs font-bold text-indigo-600">{s.time}</div>
                       <div className="text-[10px] text-slate-500 truncate">{s.text.substring(0, 40)}...</div>
                    </div>
                 ))}
                 {snapshots.length === 0 && <div className="text-xs text-slate-400">Nenhum snapshot salvo.</div>}
              </div>
           </div>
        )}

        {showAIHelp && (
           <div className="absolute inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-center justify-center p-8">
              <div className="bg-white rounded-2xl p-8 max-w-lg w-full shadow-2xl animate-fade-in">
                <h3 className="text-lg font-bold text-slate-800 mb-4">Insight da IA</h3>
                <div className="bg-slate-50 p-4 rounded-xl text-slate-700 italic border border-slate-100 max-h-60 overflow-y-auto mb-4 whitespace-pre-wrap">{aiSuggestion}</div>
                <div className="flex gap-2">
                  <button onClick={() => setShowAIHelp(false)} className="flex-1 py-3 border rounded-xl font-bold text-slate-600 hover:bg-slate-50">Fechar</button>
                  <button onClick={() => { updateContent(localContent + "\n\n" + aiSuggestion); setShowAIHelp(false); }} className="flex-1 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700">Inserir no Texto</button>
                </div>
              </div>
           </div>
        )}

        {/* --- MAIN EDITOR CANVAS --- */}
        <div className="flex-1 flex overflow-hidden relative">
          <div className={`flex-1 overflow-y-auto overflow-x-hidden flex justify-center py-12 transition-colors duration-500 ${isDistractionFree ? 'bg-[#1a1a1a]' : 'bg-[#e2e8f0]'}`}>
            
            <div className="transition-transform duration-200 origin-top" style={{ transform: `scale(${zoomLevel})` }}>
              <div 
                className={`transition-all duration-300 shadow-2xl shadow-slate-400/20 ${settings.pageSize === 'a5' ? 'w-[148mm] min-h-[210mm]' : 'w-[210mm] min-h-[297mm]'} rounded-sm flex bg-white`}
                style={{ backgroundColor: settings.pageColor }}
              >
                <div className={`flex-1 h-full flex flex-col ${settings.margins === 'compact' ? 'p-12' : settings.margins === 'wide' ? 'p-24' : 'p-[25mm]'}`}>
                  <input 
                    value={localTitle}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    style={{ color: settings.textColor, fontFamily: settings.fontFamily, textAlign: settings.textAlign }}
                    className="text-4xl font-bold bg-transparent border-none outline-none placeholder-opacity-50 mb-8 w-full"
                    placeholder="Título do Capítulo..."
                  />

                  <textarea
                    ref={editorRef}
                    value={localContent}
                    onChange={(e) => updateContent(e.target.value)}
                    style={{ 
                       fontFamily: settings.fontFamily, 
                       fontSize: settings.fontSize, 
                       lineHeight: settings.lineHeight, 
                       color: settings.textColor, 
                       textAlign: settings.textAlign 
                    }}
                    className={`flex-1 w-full bg-transparent border-none outline-none resize-none p-0 overflow-hidden ${zenMode ? 'zen-mode-active' : ''}`}
                    placeholder="Sua história começa aqui..."
                    spellCheck={false}
                  />
                  
                  {zenMode && (
                     <style>{`
                       .zen-mode-active {
                         mask-image: linear-gradient(to bottom, transparent 0%, black 40%, black 60%, transparent 100%);
                         -webkit-mask-image: linear-gradient(to bottom, transparent 0%, black 40%, black 60%, transparent 100%);
                       }
                     `}</style>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>

        {!isDistractionFree && (
          <footer className="h-8 bg-white border-t border-slate-200 flex items-center justify-between px-6 text-[10px] font-bold text-slate-400 z-20">
            <span>{settings.atmosphere !== 'none' ? `🎵 Tocando: ${settings.atmosphere}` : '🎵 Sem som ambiente'}</span>
            <span>{settings.fontFamily} • {settings.fontSize}</span>
          </footer>
        )}

      </div>
    </div>
  );
};

export default Writer;

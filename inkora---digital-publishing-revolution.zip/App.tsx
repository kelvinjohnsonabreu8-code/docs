
import React, { useState, useEffect, useCallback } from 'react';
import { AppView, Book, User, ToastMessage, ToastType } from './types';
import Sidebar from './components/Sidebar';
import Library from './components/Library';
import Writer from './components/Writer';
import DesignCenter from './components/DesignCenter';
import Marketplace from './components/Marketplace';
import Dashboard from './components/Dashboard';
import Login from './components/Login';

const INITIAL_BOOKS: Book[] = [
  {
    id: '1',
    title: 'O Despertar da Aurora',
    author: 'Elena Martins',
    description: 'Uma jornada épica pelas terras de Inkora.',
    coverUrl: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?auto=format&fit=crop&q=80&w=400',
    category: 'Fantasia',
    status: 'draft',
    chapters: [
      { id: 'c1', title: 'Prólogo', content: 'Era uma vez...', order: 1 },
      { id: 'c2', title: 'O Chamado', content: 'A jornada começa aqui.', order: 2 }
    ]
  }
];

// --- CINEMATIC BOOK SPLASH SCREEN (UPDATED v4.5) ---
const SplashScreen = ({ onFinish }: { onFinish: () => void }) => {
  useEffect(() => {
    const timer = setTimeout(() => onFinish(), 6000); 
    return () => clearTimeout(timer);
  }, [onFinish]);

  return (
    <div className="fixed inset-0 bg-slate-950 flex items-center justify-center z-[9999] overflow-hidden">
      <div className="cinematic-scene">
         <div className="cinematic-book">
            <div className="c-cover c-cover-front">
               <div className="c-cover-logo">INKORA</div>
            </div>
            <div className="c-spine"></div>
            <div className="c-back"></div>
            
            <div className="c-page"></div>
            <div className="c-page"></div>
            <div className="c-page">
               <div className="c-page-content"></div>
            </div>
            <div className="c-page"></div>
         </div>
         
         <div className="absolute bottom-16 text-center animate-[fadeInUp_1s_3.5s_forwards] opacity-0">
            <h1 className="text-3xl font-serif text-white tracking-widest mb-2 drop-shadow-xl">INKORA</h1>
            <div className="flex items-center justify-center gap-3">
               <span className="h-px w-12 bg-indigo-500/50"></span>
               <span className="text-indigo-300 font-mono text-xs tracking-[0.3em] uppercase">Versão 4.5 Ultimate</span>
               <span className="h-px w-12 bg-indigo-500/50"></span>
            </div>
         </div>
      </div>
    </div>
  );
};

const ToastContainer = ({ toasts, removeToast }: { toasts: ToastMessage[], removeToast: (id: string) => void }) => {
  return (
    <div className="fixed bottom-6 right-6 z-[1000] flex flex-col gap-3">
      {toasts.map(toast => (
        <div 
          key={toast.id}
          className={`
            min-w-[300px] p-4 rounded-xl shadow-2xl backdrop-blur-md border animate-slide-in flex items-center gap-3
            ${toast.type === 'success' ? 'bg-emerald-50/90 border-emerald-200 text-emerald-800' : ''}
            ${toast.type === 'error' ? 'bg-red-50/90 border-red-200 text-red-800' : ''}
            ${toast.type === 'info' ? 'bg-indigo-50/90 border-indigo-200 text-indigo-800' : ''}
          `}
        >
          {toast.type === 'success' && <svg className="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>}
          {toast.type === 'error' && <svg className="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>}
          <div className="flex-1 text-sm font-bold">{toast.message}</div>
        </div>
      ))}
    </div>
  );
};

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [currentView, setCurrentView] = useState<AppView>(AppView.LIBRARY);
  const [books, setBooks] = useState<Book[]>(INITIAL_BOOKS);
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  const [needsApiKey, setNeedsApiKey] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    const checkKey = async () => {
      if (window.aistudio && !(await window.aistudio.hasSelectedApiKey())) { /* Check */ }
    };
    checkKey();
  }, []);

  const addToast = useCallback((message: string, type: ToastType = 'info') => {
    const id = Date.now().toString();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 4000);
  }, []);

  const handleOpenKeySelector = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setNeedsApiKey(false);
    }
  };

  const handleUpdateBook = useCallback((updatedBook: Book) => {
    setBooks(prev => prev.map(b => b.id === updatedBook.id ? updatedBook : b));
  }, []);

  const handleCreateBook = useCallback(() => {
    if (!user) return;
    const newBook: Book = {
      id: Date.now().toString(),
      title: 'Novo Projeto v4',
      author: user.name,
      description: 'Breve descrição do seu novo projeto.',
      category: 'Geral',
      status: 'draft',
      chapters: [{ id: 'new-c1', title: 'Capítulo 1', content: '', order: 1 }]
    };
    setBooks(prev => [newBook, ...prev]);
    setActiveBookId(newBook.id);
    setCurrentView(AppView.WRITER);
    addToast('Projeto v4.5 iniciado!', 'success');
  }, [user, addToast]);

  const handleSelectBook = useCallback((id: string) => {
    setActiveBookId(id);
    setCurrentView(AppView.WRITER);
  }, []);

  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  if (!user) {
    return <Login onLogin={(u) => setUser(u)} />;
  }

  const activeBook = books.find(b => b.id === activeBookId);

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden animate-page-enter">
      {/* HAMBURGER MENU BUTTON */}
      <button 
        onClick={() => setIsSidebarOpen(true)}
        className="fixed top-4 left-4 z-[60] p-3 bg-white/80 backdrop-blur shadow-md rounded-xl text-slate-700 hover:bg-white hover:scale-105 transition-all group"
        title="Abrir Menu"
      >
        <div className="space-y-1.5">
           <span className="block w-6 h-0.5 bg-slate-800 rounded-full group-hover:w-5 transition-all"></span>
           <span className="block w-6 h-0.5 bg-slate-800 rounded-full group-hover:w-6 transition-all"></span>
           <span className="block w-6 h-0.5 bg-slate-800 rounded-full group-hover:w-4 transition-all"></span>
        </div>
      </button>

      <Sidebar 
        currentView={currentView} 
        setView={setCurrentView} 
        onCreateBook={handleCreateBook}
        user={user}
        onOpenConfig={() => setNeedsApiKey(true)}
        isOpen={isSidebarOpen}
        onClose={() => setIsSidebarOpen(false)}
      />
      
      <main className="flex-1 overflow-y-auto relative bg-slate-50/50 w-full">
        <ToastContainer toasts={toasts} removeToast={(id) => setToasts(prev => prev.filter(t => t.id !== id))} />

        {/* API Warning Modal */}
        {needsApiKey && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
             <div className="bg-white max-w-md w-full rounded-[2.5rem] p-10 shadow-2xl">
                <h3 className="text-2xl font-bold mb-4">Atenção</h3>
                <p className="mb-6">Selecione sua chave de API para continuar.</p>
                <button onClick={handleOpenKeySelector} className="w-full py-3 bg-indigo-600 text-white rounded-xl">Selecionar Chave</button>
             </div>
          </div>
        )}

        <div className="h-full animate-page-enter" key={currentView}>
          {currentView === AppView.LIBRARY && (
            <Library books={books} onSelectBook={handleSelectBook} />
          )}

          {currentView === AppView.WRITER && activeBook && (
            <Writer book={activeBook} onUpdateBook={handleUpdateBook} addToast={addToast} />
          )}

          {currentView === AppView.DESIGN && activeBook && (
             <DesignCenter book={activeBook} onUpdateBook={handleUpdateBook} addToast={addToast} />
          )}

          {currentView === AppView.STORE && (
             <Marketplace books={books.filter(b => b.status === 'published')} />
          )}

          {currentView === AppView.DASHBOARD && (
             <Dashboard books={books} />
          )}
        </div>
      </main>
    </div>
  );
};

export default App;

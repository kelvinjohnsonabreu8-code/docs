
import { GoogleGenAI } from "@google/genai";

/**
 * Melhora um texto literário usando o modelo Gemini 3 Flash.
 */
export const improveText = async (text: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Você é um editor literário profissional com décadas de experiência. 
      Sua tarefa é reescrever o texto abaixo para torná-lo mais envolvente, corrigindo gramática e melhorando o vocabulário, 
      mas preservando estritamente a voz e o estilo do autor. 
      Texto: \n\n${text}`,
      config: {
        temperature: 0.7,
        topP: 0.95,
      }
    });

    if (!response.text) {
      console.warn("Gemini retornou uma resposta vazia para melhoria de texto.");
      return null;
    }

    return response.text;
  } catch (error: any) {
    console.error("Erro na API Gemini (improveText):", error);
    if (error.message?.includes("entity was not found")) {
      // Sinaliza falha de autenticação/projeto para o UI
      throw new Error("KEY_NOT_FOUND");
    }
    return null;
  }
};

/**
 * Gera uma imagem de capa usando o modelo Gemini 2.5 Flash Image.
 */
export const generateCoverImage = async (prompt: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          { text: `Capa de livro profissional e artística. Tema: ${prompt}. Estilo cinematográfico, alta resolução, sem textos genéricos, composição centralizada.` }
        ]
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4"
        }
      }
    });

    const candidates = response.candidates;
    if (candidates && candidates.length > 0) {
      for (const part of candidates[0].content.parts) {
        if (part.inlineData) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }
    
    console.warn("Nenhuma imagem gerada pelo Gemini.");
    return null;
  } catch (error: any) {
    console.error("Erro na API Gemini (generateCoverImage):", error);
    if (error.message?.includes("entity was not found")) {
      throw new Error("KEY_NOT_FOUND");
    }
    return null;
  }
};

/**
 * Sugere desdobramentos de trama (Plot) com base no contexto.
 */
export const suggestPlot = async (currentContext: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Contexto do livro: \n\n${currentContext}\n\nO que acontece a seguir? Dê uma sugestão criativa e surpreendente em um parágrafo.`,
    });

    return response.text || null;
  } catch (error: any) {
    console.error("Erro na API Gemini (suggestPlot):", error);
    return null;
  }
};

/**
 * Gera um perfil de personagem completo.
 */
export const generateCharacterProfile = async (genre: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Crie um perfil de personagem fascinante para uma história do gênero: ${genre}.
      Inclua:
      - Nome
      - Idade
      - Aparência (descrição breve)
      - Maior Medo
      - Desejo Principal
      - Um Segredo Sombrio
      Formate de forma limpa e legível.`,
    });
    return response.text || null;
  } catch (error) {
    console.error("Erro ao gerar personagem", error);
    return null;
  }
};

/**
 * Busca sinônimos contextualizados para uma palavra.
 */
export const getSynonyms = async (word: string): Promise<string[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Liste 5 sinônimos sofisticados ou literários para a palavra "${word}". Retorne APENAS as palavras separadas por vírgula, sem explicações.`,
    });

    if (response.text) {
      return response.text.split(',').map(s => s.trim());
    }
    return [];
  } catch (error) {
    console.error("Erro ao buscar sinônimos", error);
    return [];
  }
};

/**
 * Gera nomes baseados em gênero.
 */
export const generateNames = async (category: string): Promise<string[]> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Gere 5 nomes criativos e únicos para personagens de um livro de gênero: ${category}. 
      Retorne APENAS os nomes separados por vírgula.`,
    });

    if (response.text) {
      return response.text.split(',').map(s => s.trim());
    }
    return [];
  } catch (error) {
    return [];
  }
};

/**
 * Técnica Show, Don't Tell para emoções.
 */
export const getEmotionDetails = async (emotion: string): Promise<string | null> => {
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Para a emoção "${emotion}", forneça uma lista de sinais físicos e linguagem corporal para usar na técnica "Show, Don't Tell" (Mostre, não conte). 
      Exemplo: Se for "Raiva", descreva punhos cerrados, rosto vermelho, etc.
      Seja breve e direto.`,
    });
    return response.text || null;
  } catch (error) {
    return null;
  }
};
